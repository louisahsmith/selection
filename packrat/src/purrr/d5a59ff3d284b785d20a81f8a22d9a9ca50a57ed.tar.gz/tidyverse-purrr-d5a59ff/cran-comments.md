
The rchk issues on the CRAN page should be fixed by <https://github.com/tidyverse/purrr/commit/d920b29>

## Test environments

* local OS X install, R-release
* ubuntu 12.04, R 3.1 -> R-devel
* win-builder (R-devel)

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 469 reverse dependencies (451 from CRAN + 18 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

We failed to check 10 packages. There were no new problems.
